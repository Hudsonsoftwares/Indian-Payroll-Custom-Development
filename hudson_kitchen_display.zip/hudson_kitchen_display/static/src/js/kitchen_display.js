(function () {
    "use strict";

    const root = document.getElementById("kitchen_display_root");
    if (!root) {
        return; // Not on the kitchen display page
    }

    const displayId = root.dataset.displayId;
    let stages = [];
    let orders = [];
    let currentFilter = "all";
    let currentTimeFilter = "all";
    let currentPreset = "all";
    let zoomLevel = 0;
    let highContrast = localStorage.getItem("hkd_high_contrast") === "1";
    let soundOn = localStorage.getItem("hkd_sound") !== "0";
    let knownOrderIds = new Set();
    let audioCtx = null;

    async function rpc(route, params) {
        const res = await fetch(route, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ jsonrpc: "2.0", method: "call", params: params || {}, id: Date.now() }),
        });
        const data = await res.json();
        if (data.error) {
            console.error("Kitchen display RPC error:", data.error);
            throw new Error(data.error.data ? data.error.data.message : "RPC Error");
        }
        return data.result;
    }

    function beep(freq, duration) {
        if (!soundOn) return;
        try {
            audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.frequency.value = freq;
            osc.type = "sine";
            gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + duration);
        } catch (e) {
            // Some browsers require a user gesture before audio can play - ignore.
        }
    }

    function stageColor(idx) {
        if (typeof idx === "string" && (idx.startsWith("#") || idx.startsWith("rgb"))) {
            return idx;
        }
        const palette = ["#8d8d8d", "#e57373", "#f2c94c", "#4a90d9", "#7ed957", "#9b59b6", "#e67e22", "#1abc9c"];
        return palette[(idx || 0) % palette.length];
    }

    function minutesAgo(dateStr) {
        const created = new Date(dateStr.replace(" ", "T") + "Z");
        return Math.max(0, Math.floor((Date.now() - created.getTime()) / 60000));
    }

    function applyTheme() {
        root.classList.toggle("hkd-contrast", highContrast);
        const btn = document.getElementById("kd-contrast");
        if (btn) btn.classList.toggle("active", highContrast);
        const soundBtn = document.getElementById("kd-sound");
        if (soundBtn) soundBtn.textContent = soundOn ? "\uD83D\uDD0A" : "\uD83D\uDD07";
    }

    function buildLayout() {
        root.innerHTML = `
        <div class="kd-app">
            <div class="kd-header">
                <button class="kd-icon-btn" id="kd-close-x" title="Close">&#10005;</button>
                <div class="kd-tabs" id="kd-tabs"></div>
                <div class="kd-actions">
                    <button class="kd-icon-btn" id="kd-sound" title="Toggle sound">\uD83D\uDD0A</button>
                    <button class="kd-btn" id="kd-contrast" title="High contrast mode">Contrast</button>
                    <button class="kd-btn" id="kd-recall">&#8634; Recall</button>
                    <button class="kd-btn kd-btn-primary" id="kd-close-btn">Close &#8594;</button>
                </div>
            </div>
            <div class="kd-body">
                <div class="kd-sidebar">
                    <div class="kd-side-title">Time</div>
                    <div class="kd-side-item active" data-time="all">All</div>
                    <div class="kd-side-item" data-time="now">Now</div>
                    <div class="kd-side-item" data-time="today">Today</div>
                    <div class="kd-side-item" data-time="tomorrow">Tomorrow</div>
                    <div class="kd-side-item" data-time="next">Next days</div>
                    <div class="kd-side-title">Preset</div>
                    <div class="kd-side-item active" data-preset="all">All</div>
                    <div class="kd-side-item" data-preset="dine_in">Dine In</div>
                    <div class="kd-side-item" data-preset="takeout">Takeout</div>
                    <div class="kd-side-item" data-preset="delivery">Delivery</div>
                    <div class="kd-zoom">
                        <button class="kd-btn" id="kd-zoom-out">-</button>
                        <button class="kd-btn" id="kd-zoom-in">+</button>
                    </div>
                </div>
                <div class="kd-orders" id="kd-orders"></div>
            </div>
        </div>`;

        document.getElementById("kd-close-x").onclick = () => window.close();
        document.getElementById("kd-close-btn").onclick = () => window.close();
        document.getElementById("kd-recall").onclick = onRecallLast;
        document.getElementById("kd-zoom-in").onclick = () => adjustZoom(1);
        document.getElementById("kd-zoom-out").onclick = () => adjustZoom(-1);
        document.getElementById("kd-contrast").onclick = () => {
            highContrast = !highContrast;
            localStorage.setItem("hkd_high_contrast", highContrast ? "1" : "0");
            applyTheme();
        };
        document.getElementById("kd-sound").onclick = () => {
            soundOn = !soundOn;
            localStorage.setItem("hkd_sound", soundOn ? "1" : "0");
            applyTheme();
            if (soundOn) beep(880, 0.1);
        };

        root.querySelectorAll("[data-time]").forEach((el) => {
            el.onclick = () => {
                root.querySelectorAll("[data-time]").forEach((e) => e.classList.remove("active"));
                el.classList.add("active");
                currentTimeFilter = el.dataset.time;
                renderOrders();
            };
        });
        root.querySelectorAll("[data-preset]").forEach((el) => {
            el.onclick = () => {
                root.querySelectorAll("[data-preset]").forEach((e) => e.classList.remove("active"));
                el.classList.add("active");
                currentPreset = el.dataset.preset;
                renderOrders();
            };
        });

        applyTheme();
    }

    function adjustZoom(delta) {
        zoomLevel = Math.max(-2, Math.min(3, zoomLevel + delta));
        document.getElementById("kd-orders").style.fontSize = 14 + zoomLevel * 2 + "px";
    }

    function renderTabs() {
        const tabsEl = document.getElementById("kd-tabs");
        const counts = { all: orders.length };
        stages.forEach((s) => (counts[s.id] = orders.filter((o) => o.stage_id === s.id).length));
        let html = `<button class="kd-tab ${currentFilter === "all" ? "active" : ""}" data-filter="all">All <b>${counts.all}</b></button>`;
        stages.forEach((s) => {
            html += `<button class="kd-tab ${currentFilter == s.id ? "active" : ""}" style="--kd-tab-color:${stageColor(s.color)}" data-filter="${s.id}">${s.name} <b>${counts[s.id] || 0}</b></button>`;
        });
        tabsEl.innerHTML = html;
        tabsEl.querySelectorAll(".kd-tab").forEach((btn) => {
            btn.onclick = () => {
                currentFilter = btn.dataset.filter;
                renderTabs();
                renderOrders();
            };
        });
    }

    function passesTimeFilter(order) {
        if (currentTimeFilter === "all") return true;
        const created = new Date(order.create_date.replace(" ", "T") + "Z");
        const now = new Date();
        const tomorrow = new Date(now);
        tomorrow.setDate(now.getDate() + 1);
        if (currentTimeFilter === "now") return minutesAgo(order.create_date) < 30;
        if (currentTimeFilter === "today") return created.toDateString() === now.toDateString();
        if (currentTimeFilter === "tomorrow") return created.toDateString() === tomorrow.toDateString();
        if (currentTimeFilter === "next") return created > tomorrow;
        return true;
    }

    function renderOrders() {
        const container = document.getElementById("kd-orders");
        const filtered = orders.filter((o) => {
            if (currentFilter !== "all" && String(o.stage_id) !== String(currentFilter)) return false;
            if (currentPreset !== "all" && o.fulfillment_type !== currentPreset) return false;
            if (!passesTimeFilter(o)) return false;
            return true;
        });

        if (!filtered.length) {
            container.innerHTML = `<div class="kd-empty">No orders here right now.</div>`;
            return;
        }

        let anyLateNew = false;
        container.innerHTML = filtered
            .map((o) => {
                const stage = stages.find((s) => s.id === o.stage_id);
                const stageIdx = stages.indexOf(stage);
                const age = minutesAgo(o.create_date);
                const late = stage && stage.alert_timer > 0 && age >= stage.alert_timer;
                if (late) anyLateNew = true;
                return `
            <div class="kd-card ${late ? "kd-late" : ""}" style="--kd-stage-color:${stageColor(stage ? stage.color : 0)}">
                <div class="kd-card-head">
                    <span>#${o.pos_reference || o.id}</span>
                    <span class="kd-age">${age}'</span>
                </div>
                <div class="kd-card-sub">${o.table_number ? "Table " + o.table_number : (o.fulfillment_type || "").replace("_", " ")}</div>
                <ul class="kd-lines">
                    ${o.lines
                        .map(
                            (l) =>
                                `<li>${l.qty} &times; ${l.name}${l.note ? ' <i class="kd-note">- ' + l.note + "</i>" : ""}</li>`
                        )
                        .join("")}
                </ul>
                <div class="kd-card-actions">
                    <button class="kd-undo" data-order="${o.id}" ${stageIdx <= 0 ? "disabled" : ""} title="Back one stage">&#8592; Undo</button>
                    <button class="kd-advance" data-order="${o.id}">Advance &#8594;</button>
                </div>
            </div>`;
            })
            .join("");

        if (anyLateNew) {
            beep(440, 0.25);
        }

        container.querySelectorAll(".kd-advance").forEach((btn) => {
            btn.onclick = async () => {
                const order = orders.find((o) => o.id == btn.dataset.order);
                const stage = stages.find((s) => s.id === order.stage_id);
                const idx = stages.indexOf(stage);
                const next = stages[idx + 1];
                if (next) {
                    btn.disabled = true;
                    await rpc("/hudson_kitchen_display/change_stage", { order_id: order.id, stage_id: next.id });
                    fetchAndRender();
                }
            };
        });
        container.querySelectorAll(".kd-undo").forEach((btn) => {
            btn.onclick = async () => {
                btn.disabled = true;
                await rpc("/hudson_kitchen_display/previous_stage", { order_id: btn.dataset.order });
                fetchAndRender();
            };
        });
    }

    async function onRecallLast() {
        if (!stages.length) return;
        const lastStage = stages[stages.length - 1];
        const done = orders
            .filter((o) => o.stage_id === lastStage.id)
            .sort((a, b) => new Date(b.create_date) - new Date(a.create_date))[0];
        if (done) {
            await rpc("/hudson_kitchen_display/recall", { order_id: done.id });
            fetchAndRender();
        }
    }

    async function fetchAndRender() {
        try {
            const data = await rpc("/hudson_kitchen_display/get_orders", { display_id: displayId });
            const newIds = new Set(data.orders.map((o) => o.id));
            let hasNew = false;
            newIds.forEach((id) => {
                if (!knownOrderIds.has(id)) hasNew = true;
            });
            if (knownOrderIds.size && hasNew) {
                beep(660, 0.2);
            }
            knownOrderIds = newIds;
            stages = data.stages;
            orders = data.orders;
            renderTabs();
            renderOrders();
        } catch (e) {
            const container = document.getElementById("kd-orders");
            if (container) {
                container.innerHTML = `<div class="kd-empty">Could not load orders. Check the display is configured and you are logged in.</div>`;
            }
        }
    }

    function connectRealtime() {
        // Best-effort websocket push for near-instant refresh. Falls back to
        // plain polling (below) if this fails to connect for any reason -
        // websocket path/protocol can differ slightly across Odoo versions.
        try {
            const proto = window.location.protocol === "https:" ? "wss://" : "ws://";
            const ws = new WebSocket(proto + window.location.host + "/websocket");
            ws.onopen = () => {
                ws.send(JSON.stringify({
                    event_name: "subscribe",
                    data: { channels: [`pos_prep_display-${displayId}`], last: 0 },
                }));
            };
            ws.onmessage = () => fetchAndRender();
            ws.onerror = () => {};
        } catch (e) {
            // no websocket support / blocked - polling below still covers us
        }
    }

    buildLayout();
    fetchAndRender();
    connectRealtime();
    setInterval(fetchAndRender, 8000); // safety-net poll even if websocket is connected
})();
