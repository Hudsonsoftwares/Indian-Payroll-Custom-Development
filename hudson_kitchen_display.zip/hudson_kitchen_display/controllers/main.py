from datetime import timedelta

from werkzeug.exceptions import Forbidden

from odoo import http, fields
from odoo.http import request


def _has_kitchen_access(env):
    user = env.user
    if user.has_group('point_of_sale.group_pos_user') or user.has_group('point_of_sale.group_pos_manager'):
        return True
    return bool(getattr(user, 'kitchen_screen_access', False))


class KitchenDisplayController(http.Controller):

    # ------------------------------------------------------------------
    # Kitchen (internal, staff-facing) screen
    # ------------------------------------------------------------------
    @http.route('/hudson_kitchen_display/web', type='http', auth='user')
    def kitchen_display_page(self, display_id=None, **kwargs):
        if not _has_kitchen_access(request.env):
            raise Forbidden()
        display = request.env['pos.prep.display'].browse(int(display_id)) if display_id else None
        return request.render('hudson_kitchen_display.kitchen_display_page', {
            'display_id': display.id if display else '',
            'display_name': display.name if display else 'Kitchen Display',
        })

    @http.route('/hudson_kitchen_display/get_orders', type='json', auth='user')
    def get_orders(self, display_id):
        if not _has_kitchen_access(request.env):
            return {'error': 'access_denied'}
        display = request.env['pos.prep.display'].browse(int(display_id))
        orders = request.env['pos.prep.order'].search([('display_id', '=', display.id)])
        return {
            'display_name': display.name,
            'stages': [
                {'id': s.id, 'name': s.name, 'sequence': s.sequence,
                 'color': s.color, 'alert_timer': s.alert_timer}
                for s in display.stage_ids.sorted('sequence')
            ],
            'orders': [{
                'id': o.id,
                'pos_order_id': o.pos_order_id.id,
                'pos_reference': o.pos_order_id.pos_reference,
                'table_number': o.table_number or 'T1',
                'customer_count': o.customer_count or getattr(o.pos_order_id, 'customer_count', 2) or 2,
                'fulfillment_type': o.fulfillment_type or 'dine_in',
                'stage_id': o.stage_id.id,
                'create_date': fields.Datetime.to_string(o.create_date),
                'minutes_ago': int(round((fields.Datetime.now() - o.create_date).total_seconds() / 60)) if o.create_date else 0,
                'lines': [{'name': l.name, 'qty': int(l.qty) if float(l.qty).is_integer() else l.qty, 'note': l.note} for l in o.line_ids],
            } for o in orders],
        }

    @http.route('/hudson_kitchen_display/change_stage', type='json', auth='user')
    def change_stage(self, order_id, stage_id):
        if not _has_kitchen_access(request.env):
            return False
        order = request.env['pos.prep.order'].browse(int(order_id))
        order.write({'stage_id': int(stage_id)})
        order._notify_display()
        return True

    @http.route('/hudson_kitchen_display/previous_stage', type='json', auth='user')
    def previous_stage(self, order_id):
        if not _has_kitchen_access(request.env):
            return False
        order = request.env['pos.prep.order'].browse(int(order_id))
        order.action_previous_stage()
        return True

    @http.route('/hudson_kitchen_display/recall', type='json', auth='user')
    def recall(self, order_id):
        if not _has_kitchen_access(request.env):
            return False
        order = request.env['pos.prep.order'].browse(int(order_id))
        order.action_recall()
        return True

    @http.route('/hudson_kitchen_display/reset_all', type='json', auth='user')
    def reset_all(self, display_id):
        if not _has_kitchen_access(request.env):
            return False
        display = request.env['pos.prep.display'].browse(int(display_id))
        display.action_reset_all_orders()
        return True

    # ------------------------------------------------------------------
    # Manual "Send to Kitchen" (see pos_send_button.js - experimental)
    # ------------------------------------------------------------------
    @http.route('/hudson_kitchen_display/manual_send_last_order', type='json', auth='user')
    def manual_send_last_order(self):
        order = request.env['pos.order'].sudo().search([
            ('create_uid', '=', request.env.uid),
            ('create_date', '>=', fields.Datetime.now() - timedelta(minutes=30)),
        ], order='create_date desc', limit=1)
        if not order:
            return {'ok': False}
        order.action_manual_send_to_kitchen()
        return {'ok': True, 'order_id': order.id}

    @http.route('/hudson_kitchen_display/manual_send/<int:order_id>', type='json', auth='user')
    def manual_send(self, order_id):
        order = request.env['pos.order'].sudo().browse(order_id)
        if not order.exists():
            return {'ok': False}
        order.action_manual_send_to_kitchen()
        return {'ok': True}

    # ------------------------------------------------------------------
    # Customer-facing order status screen (public, token protected)
    # ------------------------------------------------------------------
    @http.route('/pos-order-status/<string:access_token>', type='http', auth='public')
    def order_status_page(self, access_token, **kwargs):
        order = request.env['pos.order'].sudo().search(
            [('kitchen_access_token', '=', access_token)], limit=1)
        if not order:
            return request.not_found()
        return request.render('hudson_kitchen_display.order_status_page', {
            'order_id': order.id,
        })

    @http.route('/hudson_kitchen_display/get_order_status', type='json', auth='public')
    def get_order_status(self, order_id):
        order = request.env['pos.order'].sudo().browse(int(order_id))
        prep = order.prep_order_ids[:1]
        if not prep:
            return {'stage_name': 'Order received', 'sequence': 0, 'total_stages': 1}
        stages = prep.display_id.stage_ids.sorted('sequence')
        return {
            'stage_name': prep.stage_id.name,
            'sequence': prep.stage_id.sequence,
            'total_stages': len(stages),
        }

    @http.route('/hudson_kitchen_display/order_status', type='http', auth='public')
    def display_order_status_page(self, display_id=None, **kwargs):
        display = request.env['pos.prep.display'].sudo().browse(int(display_id)) if display_id else None
        return request.render('hudson_kitchen_display.display_order_status_page', {
            'display_id': display.id if display else '',
            'display_name': display.name if display else 'Order Status',
        })

    @http.route('/hudson_kitchen_display/get_display_orders_status', type='json', auth='public')
    def get_display_orders_status(self, display_id):
        display = request.env['pos.prep.display'].sudo().browse(int(display_id)) if display_id else None
        if not display or not display.exists():
            return {'ready': [], 'preparing': []}
        stages = display.stage_ids.sorted('sequence')
        if not stages:
            return {'ready': [], 'preparing': []}

        last_stage = stages[-1]
        ready_stage = stages[-2] if len(stages) > 1 else stages[0]

        orders = request.env['pos.prep.order'].sudo().search([('display_id', '=', display.id)])
        ready_orders = []
        prep_orders = []
        for o in orders:
            ref = o.pos_order_id.pos_reference or str(o.pos_order_id.id or o.id)
            display_num = ref.split()[-1] if ' ' in ref else ref
            if o.stage_id.id == ready_stage.id:
                ready_orders.append({'id': o.id, 'reference': display_num})
            elif o.stage_id.id != last_stage.id:
                prep_orders.append({'id': o.id, 'reference': display_num})
        return {
            'ready': ready_orders,
            'preparing': prep_orders,
        }
